package rachit.skutils.model;

import org.json.JSONObject;

import java.io.Serializable;

/**
 * Metadata of a Sketchware project. It maps 1:1 to the JSON stored in
 * {@code .sketchware/mysc/list/<sc_id>/project}.
 */
public class Project implements Serializable {

    public String scId = "";
    public String appName = "";
    public String workspaceName = "";
    public String packageName = "";
    public String versionCode = "1";
    public String versionName = "1.0";
    public String regDate = "";
    public double sketchwareVersion = 0;
    public boolean customIcon = false;

    public int colorPrimary = 0;
    public int colorPrimaryDark = 0;
    public int colorAccent = 0;
    public int colorControlHighlight = 0;
    public int colorControlNormal = 0;

    public static Project fromJson(String json) {
        Project project = new Project();
        if (json == null || json.trim().isEmpty()) {
            return project;
        }
        try {
            JSONObject object = new JSONObject(json);
            project.scId = object.optString("sc_id", "");
            project.appName = object.optString("my_app_name", "");
            project.workspaceName = object.optString("my_ws_name", "");
            project.packageName = object.optString("my_sc_pkg_name", "");
            project.versionCode = object.optString("sc_ver_code", "1");
            project.versionName = object.optString("sc_ver_name", "1.0");
            project.regDate = object.optString("my_sc_reg_dt", "");
            project.sketchwareVersion = object.optDouble("sketchware_ver", 0);
            project.customIcon = object.optBoolean("custom_icon", false);
            project.colorPrimary = object.optInt("color_primary", 0);
            project.colorPrimaryDark = object.optInt("color_primary_dark", 0);
            project.colorAccent = object.optInt("color_accent", 0);
            project.colorControlHighlight = object.optInt("color_control_highlight", 0);
            project.colorControlNormal = object.optInt("color_control_normal", 0);
        } catch (Exception ignored) {
        }
        return project;
    }

    public String toJson() {
        JSONObject object = new JSONObject();
        try {
            object.put("custom_icon", customIcon);
            object.put("sc_ver_code", versionCode);
            object.put("my_ws_name", workspaceName);
            object.put("color_accent", colorAccent);
            object.put("my_app_name", appName);
            object.put("sc_ver_name", versionName);
            object.put("sc_id", scId);
            object.put("color_primary", colorPrimary);
            object.put("color_control_highlight", colorControlHighlight);
            object.put("color_control_normal", colorControlNormal);
            object.put("sketchware_ver", sketchwareVersion);
            object.put("my_sc_reg_dt", regDate);
            object.put("my_sc_pkg_name", packageName);
            object.put("color_primary_dark", colorPrimaryDark);
        } catch (Exception ignored) {
        }
        return object.toString();
    }

    public String displayName() {
        if (workspaceName != null && !workspaceName.isEmpty()) {
            return workspaceName;
        }
        if (appName != null && !appName.isEmpty()) {
            return appName;
        }
        return "Project " + scId;
    }

    public String subtitle() {
        return appName + "  •  " + packageName + "  •  v" + versionName;
    }

    /** Shallow copy; used when a project has to be imported under a fresh id. */
    public Project copy() {
        Project copy = new Project();
        copy.scId = scId;
        copy.appName = appName;
        copy.workspaceName = workspaceName;
        copy.packageName = packageName;
        copy.versionCode = versionCode;
        copy.versionName = versionName;
        copy.regDate = regDate;
        copy.sketchwareVersion = sketchwareVersion;
        copy.customIcon = customIcon;
        copy.colorPrimary = colorPrimary;
        copy.colorPrimaryDark = colorPrimaryDark;
        copy.colorAccent = colorAccent;
        copy.colorControlHighlight = colorControlHighlight;
        copy.colorControlNormal = colorControlNormal;
        return copy;
    }

    @Override
    public String toString() {
        return displayName();
    }
}
