package rachit.skutils.model;

import org.json.JSONObject;

import java.io.Serializable;

/**
 * One line of a Sketchware {@code file} entry: an activity or a custom view
 * declared inside a project.
 */
public class ActivityItem implements Serializable {

    /** 0 = activity, 1 = custom view, 2 = drawer. */
    public int fileType = 0;
    public String fileName = "";
    public int orientation = 0;
    public int theme = 0;
    public int keyboardSetting = 0;
    public int options = 0;

    public static ActivityItem fromJson(String json) {
        ActivityItem item = new ActivityItem();
        if (json == null || json.trim().isEmpty()) {
            return item;
        }
        try {
            JSONObject object = new JSONObject(json);
            item.fileName = object.optString("fileName", "");
            item.fileType = object.optInt("fileType", 0);
            item.orientation = object.optInt("orientation", 0);
            item.theme = object.optInt("theme", 0);
            item.keyboardSetting = object.optInt("keyboardSetting", 0);
            item.options = object.optInt("options", 0);
        } catch (Exception ignored) {
        }
        return item;
    }

    public String toJson() {
        JSONObject object = new JSONObject();
        try {
            object.put("fileName", fileName);
            object.put("fileType", fileType);
            object.put("keyboardSetting", keyboardSetting);
            object.put("options", options);
            object.put("orientation", orientation);
            object.put("theme", theme);
        } catch (Exception ignored) {
        }
        return object.toString();
    }

    public boolean isActivity() {
        return fileType == 0;
    }

    public boolean isCustomView() {
        return fileType == 1;
    }

    public String typeLabel() {
        switch (fileType) {
            case 1:
                return "Custom View";
            case 2:
                return "Drawer";
            default:
                return "Activity";
        }
    }

    public String orientationLabel() {
        switch (orientation) {
            case 1:
                return "Landscape";
            case 2:
                return "Both";
            default:
                return "Portrait";
        }
    }

    @Override
    public String toString() {
        return fileName;
    }
}
