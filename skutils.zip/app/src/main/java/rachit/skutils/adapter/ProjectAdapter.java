package rachit.skutils.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import rachit.skutils.R;
import rachit.skutils.model.Project;

import java.util.ArrayList;
import java.util.List;

/** Shows the Sketchware projects found on the device. */
public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.ViewHolder> {

    public interface OnProjectClickListener {
        void onProjectClick(Project project, int position);
    }

    private final List<Project> projects = new ArrayList<>();
    private final OnProjectClickListener listener;

    public ProjectAdapter(OnProjectClickListener listener) {
        this.listener = listener;
    }

    public void submit(List<Project> newProjects) {
        projects.clear();
        if (newProjects != null) {
            projects.addAll(newProjects);
        }
        notifyDataSetChanged();
    }

    public List<Project> getProjects() {
        return projects;
    }

    public Project get(int position) {
        return projects.get(position);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_project, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Project project = projects.get(position);
        holder.title.setText(project.displayName());
        holder.subtitle.setText(project.packageName + "  •  v" + project.versionName
                + " (" + project.versionCode + ")");
        holder.meta.setText("ID " + project.scId);
        holder.avatar.setText(initialOf(project.displayName()));
        holder.itemView.setOnClickListener(v -> listener.onProjectClick(project, holder.getAdapterPosition()));
    }

    private static String initialOf(String name) {
        if (name == null || name.trim().isEmpty()) {
            return "?";
        }
        return name.trim().substring(0, 1).toUpperCase(java.util.Locale.US);
    }

    @Override
    public int getItemCount() {
        return projects.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView avatar;
        final TextView title;
        final TextView subtitle;
        final TextView meta;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            avatar = itemView.findViewById(R.id.avatar);
            title = itemView.findViewById(R.id.title);
            subtitle = itemView.findViewById(R.id.subtitle);
            meta = itemView.findViewById(R.id.meta);
        }
    }
}
