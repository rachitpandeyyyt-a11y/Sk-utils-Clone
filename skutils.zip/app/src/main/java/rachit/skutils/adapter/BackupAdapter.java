package rachit.skutils.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import rachit.skutils.R;
import rachit.skutils.util.FileUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Lists the {@code .swb} backup files. */
public class BackupAdapter extends RecyclerView.Adapter<BackupAdapter.ViewHolder> {

    public interface OnBackupClickListener {
        void onBackupClick(File backup);
    }

    private final List<File> backups = new ArrayList<>();
    private final OnBackupClickListener listener;

    public BackupAdapter(OnBackupClickListener listener) {
        this.listener = listener;
    }

    public void submit(List<File> newBackups) {
        backups.clear();
        if (newBackups != null) {
            backups.addAll(newBackups);
        }
        notifyDataSetChanged();
    }

    public List<File> getBackups() {
        return backups;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_project, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        File backup = backups.get(position);
        String name = backup.getName();
        holder.title.setText(FileUtil.nameWithoutExtension(name));
        holder.subtitle.setText(backup.getParentFile() == null
                ? "" : backup.getParentFile().getName());
        holder.meta.setText(FileUtil.humanReadableSize(backup.length()));
        holder.avatar.setText("⬇");
        holder.itemView.setOnClickListener(v -> listener.onBackupClick(backup));
    }

    @Override
    public int getItemCount() {
        return backups.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView avatar;
        final TextView title;
        final TextView subtitle;
        final TextView meta;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            avatar = itemView.findViewById(R.id.avatar);
            title = itemView.findViewById(R.id.title);
            subtitle = itemView.findViewById(R.id.subtitle);
            meta = itemView.findViewById(R.id.meta);
        }
    }
}
