package rachit.skutils.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import rachit.skutils.R;
import rachit.skutils.model.ActivityItem;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Multi select list of activities used by the editor and the restore picker. */
public class ActivityAdapter extends RecyclerView.Adapter<ActivityAdapter.ViewHolder> {

    public interface OnActivityClickListener {
        void onActivityClick(ActivityItem item, int position);
    }

    private final List<ActivityItem> items = new ArrayList<>();
    private final Set<String> selected = new LinkedHashSet<>();
    private final boolean selectable;
    private final OnActivityClickListener listener;

    public ActivityAdapter(boolean selectable, OnActivityClickListener listener) {
        this.selectable = selectable;
        this.listener = listener;
    }

    public void submit(List<ActivityItem> newItems) {
        items.clear();
        selected.clear();
        if (newItems != null) {
            items.addAll(newItems);
        }
        notifyDataSetChanged();
    }

    public List<ActivityItem> getItems() {
        return items;
    }

    public List<ActivityItem> getSelected() {
        List<ActivityItem> result = new ArrayList<>();
        for (ActivityItem item : items) {
            if (selected.contains(item.fileName)) {
                result.add(item);
            }
        }
        return result;
    }

    private void toggle(ActivityItem item) {
        if (!selectable) {
            return;
        }
        if (selected.contains(item.fileName)) {
            selected.remove(item.fileName);
        } else {
            selected.add(item.fileName);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_activity, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ActivityItem item = items.get(position);
        holder.name.setText(item.fileName);
        holder.type.setText(item.typeLabel() + "  •  " + item.orientationLabel());
        holder.check.setVisibility(selectable ? View.VISIBLE : View.GONE);
        holder.check.setChecked(selected.contains(item.fileName));
        holder.check.setOnCheckedChangeListener(null);
        holder.itemView.setOnClickListener(v -> {
            toggle(item);
            holder.check.setChecked(selected.contains(item.fileName));
            if (listener != null) {
                listener.onActivityClick(item, holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView name;
        final TextView type;
        final android.widget.CheckBox check;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            type = itemView.findViewById(R.id.type);
            check = itemView.findViewById(R.id.check);
        }
    }
}
