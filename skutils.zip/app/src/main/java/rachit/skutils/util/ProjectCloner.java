package rachit.skutils.util;

import rachit.skutils.model.ActivityItem;
import rachit.skutils.model.Project;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Copies whole projects or single activities between projects.
 *
 * <p>An activity is spread over several Sketchware containers:
 * {@code view} holds {@code @Name.xml}, {@code logic} holds the block
 * containers ({@code @Name.java_*}) and {@code file} declares the screen. All
 * three have to be copied and renamed together, otherwise Sketchware drops the
 * screen.</p>
 */
public final class ProjectCloner {

    private ProjectCloner() {
    }

    // ------------------------------------------------------------------
    // Whole project
    // ------------------------------------------------------------------

    /** Duplicates a project inside {@code .sketchware}, returns the new project. */
    public static Project cloneProject(String scId) {
        Project source = SketchwareUtil.readProject(scId);
        String newId = SketchwareUtil.newProjectId();

        FileUtil.copyDirectory(SketchwareUtil.projectDataDir(scId),
                SketchwareUtil.projectDataDir(newId));

        for (String type : new String[]{"images", "fonts", "sounds"}) {
            File dir = SketchwareUtil.projectResourceDir(scId, type);
            if (dir.exists()) {
                FileUtil.copyDirectory(dir, SketchwareUtil.projectResourceDir(newId, type));
            }
        }

        Project copy = new Project();
        copy.scId = newId;
        copy.appName = source.appName;
        copy.workspaceName = source.workspaceName + "Copy";
        copy.packageName = source.packageName;
        copy.versionCode = "1";
        copy.versionName = source.versionName;
        copy.regDate = SketchwareUtil.timestamp();
        copy.sketchwareVersion = source.sketchwareVersion;
        copy.customIcon = source.customIcon;
        copy.colorPrimary = source.colorPrimary;
        copy.colorPrimaryDark = source.colorPrimaryDark;
        copy.colorAccent = source.colorAccent;
        copy.colorControlHighlight = source.colorControlHighlight;
        copy.colorControlNormal = source.colorControlNormal;
        SketchwareUtil.writeProject(copy);
        return copy;
    }

    // ------------------------------------------------------------------
    // Single activity
    // ------------------------------------------------------------------

    /** Clones an activity inside the same project under a new name. */
    public static boolean cloneActivityWithin(String scId, String activityFile, String newName) {
        File dataDir = SketchwareUtil.projectDataDir(scId);
        String oldBase = FileUtil.nameWithoutExtension(activityFile);
        String newBase = FileUtil.nameWithoutExtension(newName);
        if (oldBase.equals(newBase)) {
            return false;
        }

        if (!copyViewContainer(dataDir, oldBase, newBase)) {
            return false;
        }
        copyLogicContainers(dataDir, oldBase, newBase);

        List<ActivityItem> items = SketchwareUtil.readActivities(scId);
        for (ActivityItem item : items) {
            if (item.fileName.equals(oldBase + ".java")) {
                ActivityItem copy = new ActivityItem();
                copy.fileName = newBase + ".java";
                copy.fileType = item.fileType;
                copy.orientation = item.orientation;
                copy.theme = item.theme;
                copy.keyboardSetting = item.keyboardSetting;
                copy.options = item.options;
                items.add(copy);
                break;
            }
        }
        SketchwareUtil.writeActivities(scId, items);
        return true;
    }

    /**
     * Copies an activity from one project into another project.
     *
     * @return true when the view container was found and copied
     */
    public static boolean copyActivityBetween(String fromScId, String activityFile,
                                              String toScId, String newName) {
        File fromData = SketchwareUtil.projectDataDir(fromScId);
        File toData = SketchwareUtil.projectDataDir(toScId);

        String oldBase = FileUtil.nameWithoutExtension(activityFile);
        String newBase = FileUtil.nameWithoutExtension(newName);
        if (oldBase.equals(newBase) && fromScId.equals(toScId)) {
            return false;
        }

        if (!copyViewContainer(toData, fromData, oldBase, newBase)) {
            return false;
        }
        copyLogicContainers(toData, fromData, oldBase, newBase);

        List<ActivityItem> items = SketchwareUtil.readActivities(toScId);
        ActivityItem sourceItem = null;
        for (ActivityItem item : SketchwareUtil.readActivities(fromScId)) {
            if (item.fileName.equals(oldBase + ".java")) {
                sourceItem = item;
                break;
            }
        }
        ActivityItem copy = new ActivityItem();
        copy.fileName = newBase + ".java";
        if (sourceItem != null) {
            copy.fileType = sourceItem.fileType;
            copy.orientation = sourceItem.orientation;
            copy.theme = sourceItem.theme;
            copy.keyboardSetting = sourceItem.keyboardSetting;
            copy.options = sourceItem.options;
        }
        items.add(copy);
        SketchwareUtil.writeActivities(toScId, items);
        return true;
    }

    // ------------------------------------------------------------------
    // view / logic container handling
    // ------------------------------------------------------------------

    private static boolean copyViewContainer(File dataDir, String oldBase, String newBase) {
        return copyViewContainer(dataDir, dataDir, oldBase, newBase);
    }

    private static boolean copyViewContainer(File toData, File fromData, String oldBase, String newBase) {
        String source = FileUtil.readDecrypted(new File(fromData, SketchwareUtil.VIEW_FILE));
        if (source.isEmpty()) {
            return false;
        }

        // collect the blocks that belong to the activity being copied
        List<String> copied = new ArrayList<>();
        for (String block : source.split("\n\n")) {
            String trimmed = block.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            String header = firstLine(trimmed);
            if (header.equals("@" + oldBase + ".xml") || header.equals("@" + oldBase + ".xml_fab")) {
                String renamed = trimmed.replaceFirst("^@" + quote(oldBase) + "\\.",
                        "@" + newBase + ".");
                renamed = renamed.replace(oldBase + ".xml", newBase + ".xml");
                copied.add(renamed);
            }
        }
        if (copied.isEmpty()) {
            return false;
        }

        // append to the target, never overwrite its existing screens
        File target = new File(toData, SketchwareUtil.VIEW_FILE);
        String existing;
        if (toData.equals(fromData)) {
            existing = source;
        } else {
            existing = FileUtil.readDecrypted(target);
        }
        List<String> blocks = splitBlocks(existing);
        removeBlocks(blocks, newBase);
        blocks.addAll(copied);
        FileUtil.writeEncrypted(target, joinBlocks(blocks));
        return true;
    }

    private static void copyLogicContainers(File dataDir, String oldBase, String newBase) {
        copyLogicContainers(dataDir, dataDir, oldBase, newBase);
    }

    private static void copyLogicContainers(File toData, File fromData, String oldBase, String newBase) {
        String source = FileUtil.readDecrypted(new File(fromData, SketchwareUtil.LOGIC_FILE));
        if (source.isEmpty()) {
            return;
        }

        List<String> copied = new ArrayList<>();
        for (String block : source.split("\n\n")) {
            String trimmed = block.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            String header = firstLine(trimmed);
            if (header.startsWith("@" + oldBase + ".java_")) {
                String renamed = trimmed.replaceFirst("^@" + quote(oldBase) + "\\.java_",
                        "@" + newBase + ".java_");
                copied.add(renamed);
            }
        }
        if (copied.isEmpty()) {
            return;
        }

        File target = new File(toData, SketchwareUtil.LOGIC_FILE);
        String existing = toData.equals(fromData) ? source : FileUtil.readDecrypted(target);
        List<String> blocks = splitBlocks(existing);
        removeLogicBlocks(blocks, newBase);
        blocks.addAll(copied);
        FileUtil.writeEncrypted(target, joinBlocks(blocks));
    }

    /** Drops stale view containers of the target name so a re-clone stays clean. */
    private static void removeBlocks(List<String> blocks, String base) {
        for (int i = blocks.size() - 1; i >= 0; i--) {
            String header = firstLine(blocks.get(i));
            if (header.equals("@" + base + ".xml") || header.equals("@" + base + ".xml_fab")) {
                blocks.remove(i);
            }
        }
    }

    /** Drops stale logic containers of the target name. */
    private static void removeLogicBlocks(List<String> blocks, String base) {
        for (int i = blocks.size() - 1; i >= 0; i--) {
            String header = firstLine(blocks.get(i));
            if (header.startsWith("@" + base + ".java_")) {
                blocks.remove(i);
            }
        }
    }

    private static List<String> splitBlocks(String content) {
        List<String> blocks = new ArrayList<>();
        if (content == null || content.trim().isEmpty()) {
            return blocks;
        }
        for (String block : content.split("\n\n")) {
            String trimmed = block.trim();
            if (!trimmed.isEmpty()) {
                blocks.add(trimmed);
            }
        }
        return blocks;
    }

    private static String joinBlocks(List<String> blocks) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < blocks.size(); i++) {
            sb.append(blocks.get(i));
            if (i < blocks.size() - 1) {
                sb.append("\n\n");
            }
        }
        return sb.toString();
    }

    private static String firstLine(String block) {
        int index = block.indexOf('\n');
        String line = index >= 0 ? block.substring(0, index) : block;
        return line.trim();
    }

    private static String quote(String value) {
        return java.util.regex.Pattern.quote(value);
    }
}
