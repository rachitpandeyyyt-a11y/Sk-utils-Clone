package rachit.skutils.util;

import android.os.Environment;

import rachit.skutils.model.ActivityItem;
import rachit.skutils.model.Project;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Knows where Sketchware keeps its data and how to read / write it.
 *
 * <pre>
 * .sketchware/
 *   data/&lt;sc_id&gt;/            project data (file, view, logic, library, resource...)
 *   mysc/list/&lt;sc_id&gt;/project project metadata (json, encrypted)
 *   mysc/&lt;sc_id&gt;/             generated Android project
 *   backups/&lt;name&gt;/*.swb      backups created by Sketchware / SkUtils
 *   resources/&lt;type&gt;/&lt;sc_id&gt;/ project resources (images, fonts, sounds)
 *   libs/local_libs/&lt;name&gt;/   local libraries
 * </pre>
 */
public final class SketchwareUtil {

    public static final String DATA_FILE = "file";
    public static final String VIEW_FILE = "view";
    public static final String LOGIC_FILE = "logic";
    public static final String LIBRARY_FILE = "library";
    public static final String RESOURCE_FILE = "resource";
    public static final String PROJECT_CONFIG_FILE = "project_config";
    public static final String PERMISSION_FILE = "permission";

    private SketchwareUtil() {
    }

    public static File externalRoot() {
        return Environment.getExternalStorageDirectory();
    }

    public static File sketchwareDir() {
        return new File(externalRoot(), ".sketchware");
    }

    public static File dataDir() {
        return new File(sketchwareDir(), "data");
    }

    public static File listDir() {
        return new File(sketchwareDir(), "mysc/list");
    }

    public static File backupsDir() {
        return new File(sketchwareDir(), "backups");
    }

    public static File resourcesDir() {
        return new File(sketchwareDir(), "resources");
    }

    public static File localLibsDir() {
        return new File(sketchwareDir(), "libs/local_libs");
    }

    public static File exportsDir() {
        return new File(externalRoot(), "SkUtils/exports");
    }

    public static File extractedBackupsDir() {
        return new File(externalRoot(), "SkUtils/backups");
    }

    public static boolean isSketchwareInstalled() {
        return sketchwareDir().exists() && dataDir().exists();
    }

    public static File projectDataDir(String scId) {
        return new File(dataDir(), scId);
    }

    public static File projectListDir(String scId) {
        return new File(listDir(), scId);
    }

    public static File projectMetadataFile(String scId) {
        return new File(projectListDir(scId), "project");
    }

    public static File projectResourceDir(String scId, String type) {
        return new File(resourcesDir(), type + "/" + scId);
    }

    public static Project readProject(String scId) {
        return Project.fromJson(FileUtil.readDecrypted(projectMetadataFile(scId)));
    }

    public static void writeProject(Project project) {
        FileUtil.writeEncrypted(projectMetadataFile(project.scId), project.toJson());
    }

    /** Lists every project that has a metadata file, newest first. */
    public static List<Project> listProjects() {
        List<Project> projects = new ArrayList<>();
        File[] children = listDir().listFiles();
        if (children == null) {
            return projects;
        }
        for (File child : children) {
            if (!child.isDirectory()) {
                continue;
            }
            File metadata = new File(child, "project");
            if (!metadata.exists()) {
                continue;
            }
            Project project = Project.fromJson(FileUtil.readDecrypted(metadata));
            if (project.scId == null || project.scId.isEmpty()) {
                project.scId = child.getName();
            }
            projects.add(project);
        }
        Collections.sort(projects, (a, b) -> b.regDate.compareTo(a.regDate));
        return projects;
    }

    /** Returns the next free numeric project id. */
    public static String newProjectId() {
        int max = 0;
        File[] listChildren = listDir().listFiles();
        if (listChildren != null) {
            for (File file : listChildren) {
                if (!file.getName().matches("\\d+")) {
                    continue;
                }
                try {
                    max = Math.max(max, Integer.parseInt(file.getName()));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        File[] dataChildren = dataDir().listFiles();
        if (dataChildren != null) {
            for (File file : dataChildren) {
                try {
                    if (file.getName().matches("\\d+")) {
                        max = Math.max(max, Integer.parseInt(file.getName()));
                    }
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return String.valueOf(max + 1);
    }

    public static String timestamp() {
        return new SimpleDateFormat("yyyyMMddHHmmss", Locale.US).format(new Date());
    }

    /**
     * Moves a project to the top of the list by refreshing its registration
     * date (the list is sorted newest first).
     */
    public static boolean touchProject(String scId) {
        File metadata = projectMetadataFile(scId);
        if (!metadata.exists()) {
            return false;
        }
        Project project = readProject(scId);
        project.regDate = timestamp();
        writeProject(project);
        return true;
    }

    // ---------------------------------------------------------------------
    // file / view / logic helpers
    // ---------------------------------------------------------------------

    /** Reads the list of activities & custom views declared in a project. */
    public static List<ActivityItem> readActivities(String scId) {
        return parseActivities(FileUtil.readDecrypted(new File(projectDataDir(scId), DATA_FILE)));
    }

    public static List<ActivityItem> parseActivities(String fileContent) {
        List<ActivityItem> items = new ArrayList<>();
        if (fileContent == null || fileContent.isEmpty()) {
            return items;
        }
        String[] lines = fileContent.split("\n");
        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("@")) {
                continue;
            }
            if (trimmed.startsWith("{")) {
                items.add(ActivityItem.fromJson(trimmed));
            }
        }
        return items;
    }

    public static void writeActivities(String scId, List<ActivityItem> items) {
        File file = new File(projectDataDir(scId), DATA_FILE);
        String original = FileUtil.readDecrypted(file);
        FileUtil.writeEncrypted(file, mergeActivities(original, items));
    }

    /**
     * Rewrites only the {@code @activity} and {@code @customview} sections and
     * keeps every other line of the original file untouched, so unknown
     * Sketchware sections are never lost.
     */
    public static String mergeActivities(String original, List<ActivityItem> items) {
        List<String> activityLines = new ArrayList<>();
        List<String> customViewLines = new ArrayList<>();
        for (ActivityItem item : items) {
            if (item.isCustomView()) {
                customViewLines.add(item.toJson());
            } else {
                activityLines.add(item.toJson());
            }
        }

        List<String> output = new ArrayList<>();
        boolean wroteActivity = false;
        boolean wroteCustomView = false;
        String section = null;
        String[] lines = original == null ? new String[0] : original.split("\n", -1);
        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.startsWith("@")) {
                if ("@activity".equals(trimmed)) {
                    output.add("@activity");
                    output.addAll(activityLines);
                    wroteActivity = true;
                    section = "@activity";
                    continue;
                }
                if ("@customview".equals(trimmed)) {
                    output.add("@customview");
                    output.addAll(customViewLines);
                    wroteCustomView = true;
                    section = "@customview";
                    continue;
                }
                section = trimmed;
                output.add(line);
                continue;
            }
            if (("@activity".equals(section) || "@customview".equals(section))
                    && (trimmed.isEmpty() || trimmed.startsWith("{"))) {
                continue; // old entries, already replaced above
            }
            output.add(line);
        }

        if (!wroteActivity) {
            output.add("@activity");
            output.addAll(activityLines);
        }
        if (!wroteCustomView) {
            output.add("@customview");
            output.addAll(customViewLines);
        }
        return joinLines(output);
    }

    static String joinLines(List<String> lines) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            sb.append(lines.get(i));
            if (i < lines.size() - 1) {
                sb.append('\n');
            }
        }
        return sb.toString();
    }
}
