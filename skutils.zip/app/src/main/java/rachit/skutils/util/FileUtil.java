package rachit.skutils.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Small collection of file helpers. Methods that touch Sketchware project data
 * transparently apply the Sketchware encryption.
 */
public final class FileUtil {

    private FileUtil() {
    }

    public static byte[] readRaw(File file) {
        if (file == null || !file.exists()) {
            return new byte[0];
        }
        try (InputStream in = new FileInputStream(file)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            return out.toByteArray();
        } catch (IOException e) {
            return new byte[0];
        }
    }

    public static void writeRaw(File file, byte[] data) {
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }
        try (OutputStream out = new FileOutputStream(file)) {
            out.write(data);
        } catch (IOException e) {
            // Ignored; callers surface failures through UI messages.
        }
    }

    /** Reads and decrypts a Sketchware data file (file, view, logic, project...). */
    public static String readDecrypted(File file) {
        byte[] raw = readRaw(file);
        if (raw.length == 0) {
            return "";
        }
        String text = CryptoUtil.decryptToString(raw);
        return text.isEmpty() ? new String(raw) : text;
    }

    /** Encrypts and writes a Sketchware data file. */
    public static void writeEncrypted(File file, String content) {
        writeRaw(file, CryptoUtil.encryptString(content));
    }

    public static boolean copy(File source, File destination) {
        if (source == null || !source.exists()) {
            return false;
        }
        if (source.isDirectory()) {
            return copyDirectory(source, destination);
        }
        return copyFile(source, destination);
    }

    public static boolean copyFile(File source, File destination) {
        File parent = destination.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            return false;
        }
        try (InputStream in = new FileInputStream(source);
             OutputStream out = new FileOutputStream(destination)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean copyDirectory(File source, File destination) {
        if (!destination.exists() && !destination.mkdirs()) {
            return false;
        }
        File[] children = source.listFiles();
        if (children == null) {
            return true;
        }
        boolean success = true;
        for (File child : children) {
            File target = new File(destination, child.getName());
            if (child.isDirectory()) {
                success &= copyDirectory(child, target);
            } else {
                success &= copyFile(child, target);
            }
        }
        return success;
    }

    public static boolean delete(File file) {
        if (file == null || !file.exists()) {
            return true;
        }
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    delete(child);
                }
            }
        }
        return file.delete();
    }

    /** Deletes the children of a directory but keeps the directory itself. */
    public static void clearDirectory(File directory) {
        if (directory == null || !directory.isDirectory()) {
            return;
        }
        File[] children = directory.listFiles();
        if (children != null) {
            for (File child : children) {
                delete(child);
            }
        }
    }

    public static String nameWithoutExtension(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    public static String extension(String name) {
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot + 1) : "";
    }

    public static long sizeOf(File file) {
        if (file == null || !file.exists()) {
            return 0;
        }
        if (file.isFile()) {
            return file.length();
        }
        long total = 0;
        File[] children = file.listFiles();
        if (children != null) {
            for (File child : children) {
                total += sizeOf(child);
            }
        }
        return total;
    }

    public static String humanReadableSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        String[] units = {"KB", "MB", "GB", "TB"};
        double value = bytes / 1024.0;
        int unit = 0;
        while (value >= 1024 && unit < units.length - 1) {
            value /= 1024.0;
            unit++;
        }
        return String.format("%.1f %s", value, units[unit]);
    }
}
