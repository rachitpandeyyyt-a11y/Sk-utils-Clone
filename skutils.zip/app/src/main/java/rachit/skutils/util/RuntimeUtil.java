package rachit.skutils.util;

import android.os.Build;

/** Small helper so newer API constants are only touched behind a version check. */
public final class RuntimeUtil {

    private RuntimeUtil() {
    }

    /** True on Android 11 (API 30) and above, where all files access is needed. */
    public static boolean isAtLeastR() {
        return Build.VERSION.SDK_INT >= 30;
    }

    /** True on Android 13 (API 33) and above. */
    public static boolean isAtLeastT() {
        return Build.VERSION.SDK_INT >= 33;
    }
}
