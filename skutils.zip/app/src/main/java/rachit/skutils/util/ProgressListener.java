package rachit.skutils.util;

/** Callback used by long running backup / restore operations. */
public interface ProgressListener {

    /** @param percent 0..100, or -1 when the total is not known. */
    void onProgress(String stage, int percent);

    void onFinished(boolean success, String message);
}
