package rachit.skutils.util;

import rachit.skutils.model.Project;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Creates and restores {@code .swb} backups. The archive layout is compatible
 * with Sketchware's own backups:
 *
 * <pre>
 * data/&lt;name&gt;          (file, view, logic, library, resource, ...)
 * data/files/**        assets &amp; custom java
 * data/Injection/**
 * resources/images/&lt;sc_id&gt;/**
 * resources/fonts/&lt;sc_id&gt;/**
 * resources/sounds/&lt;sc_id&gt;/**
 * resources/icons/&lt;sc_id&gt;.png
 * local_libs/&lt;name&gt;/**
 * project              (encrypted metadata of the backup)
 * </pre>
 */
public class BackupManager {

    /** Files living directly inside {@code data/<sc_id>}. */
    private static final String[] PROJECT_FILES = {
            SketchwareUtil.DATA_FILE,
            SketchwareUtil.VIEW_FILE,
            SketchwareUtil.LOGIC_FILE,
            SketchwareUtil.LIBRARY_FILE,
            SketchwareUtil.RESOURCE_FILE,
            SketchwareUtil.PROJECT_CONFIG_FILE,
            SketchwareUtil.PERMISSION_FILE,
            "view_root",
            "custom_blocks",
            "local_library",
            "build_config",
            "stringfog",
            "service",
            "java",
            "proguard",
            "proguard-rules.pro",
            "compile_log",
    };

    private static final String[] RESOURCE_TYPES = {"images", "fonts", "sounds"};

    public interface ArchiveReadable {
        InputStream openInput() throws IOException;

        String name();
    }

    // ---------------------------------------------------------------------
    // Backup
    // ---------------------------------------------------------------------

    public static File defaultBackupFile(Project project) {
        String safe = project.displayName().replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (safe.isEmpty()) {
            safe = "project";
        }
        String name = safe + " v" + project.versionName
                + " (" + project.packageName + ", " + project.versionCode + ")"
                + " " + SketchwareUtil.timestamp() + ".swb";
        // <backups>/<workspace>/<name>.swb – the layout Sketchware itself uses,
        // so the backup also shows up in Sketchware's own restore screen
        File folder = new File(SketchwareUtil.backupsDir(), safe);
        if (!folder.exists() && !folder.mkdirs()) {
            folder = SketchwareUtil.extractedBackupsDir();
            folder.mkdirs();
        }
        return new File(folder, name);
    }

    public static List<ZipEntrySource> collectEntries(Project project, boolean includeFiles,
                                                      boolean includeLocalLibs) {
        List<ZipEntrySource> entries = new ArrayList<>();
        String scId = project.scId;
        File dataDir = SketchwareUtil.projectDataDir(scId);

        for (String name : PROJECT_FILES) {
            File file = new File(dataDir, name);
            if (file.exists()) {
                entries.add(new ZipEntrySource("data/" + name, file));
            }
        }

        if (includeFiles) {
            File files = new File(dataDir, "files");
            if (files.exists()) {
                addTree(entries, files, "data/files");
            }
        } else {
            File java = new File(dataDir, "files/java");
            if (java.exists()) {
                addTree(entries, java, "data/files/java");
            }
        }

        File injection = new File(dataDir, "Injection");
        if (injection.exists()) {
            addTree(entries, injection, "data/Injection");
        }

        for (String type : RESOURCE_TYPES) {
            File dir = SketchwareUtil.projectResourceDir(scId, type);
            if (dir.exists()) {
                addTree(entries, dir, "resources/" + type + "/" + scId);
            }
        }

        // icon (stored either as <sc_id>.png or inside resources/icons)
        File icons = new File(SketchwareUtil.resourcesDir(), "icons");
        File icon = new File(icons, scId + ".png");
        if (icon.exists()) {
            entries.add(new ZipEntrySource("resources/icons/" + scId + ".png", icon));
        }

        if (includeLocalLibs) {
            String[] used = readLocalLibraries(scId);
            for (String library : used) {
                File dir = new File(SketchwareUtil.localLibsDir(), library);
                if (dir.exists()) {
                    addTree(entries, dir, "local_libs/" + library);
                }
            }
        }

        entries.add(new ZipEntrySource("project", CryptoUtil.encryptString(project.toJson())));
        return entries;
    }

    private static void addTree(List<ZipEntrySource> entries, File root, String prefix) {
        if (root.isFile()) {
            entries.add(new ZipEntrySource(prefix, root));
            return;
        }
        File[] children = root.listFiles();
        if (children == null) {
            return;
        }
        for (File child : children) {
            String path = prefix + "/" + child.getName();
            if (child.isDirectory()) {
                addTree(entries, child, path);
            } else {
                entries.add(new ZipEntrySource(path, child));
            }
        }
    }

    private static String[] readLocalLibraries(String scId) {
        String content = FileUtil.readDecrypted(
                new File(SketchwareUtil.projectDataDir(scId), "local_library"));
        if (content.trim().isEmpty()) {
            return new String[0];
        }
        List<String> result = new ArrayList<>();
        String[] lines = content.split("\n");
        for (String line : lines) {
            if (line.startsWith("@")) {
                continue;
            }
            int index = line.indexOf(':');
            String name = index >= 0 ? line.substring(0, index) : line;
            name = name.trim();
            if (!name.isEmpty()) {
                result.add(name);
            }
        }
        return result.toArray(new String[0]);
    }

    public static void createBackup(Project project, OutputStream output, boolean includeFiles,
                                    boolean includeLocalLibs, ProgressListener listener) {
        List<ZipEntrySource> entries = collectEntries(project, includeFiles, includeLocalLibs);
        ZipOutputStream zip = null;
        try {
            zip = new ZipOutputStream(output);
            zip.setLevel(6);
            int total = entries.size();
            int done = 0;
            byte[] buffer = new byte[8192];
            for (ZipEntrySource source : entries) {
                ZipEntry entry = new ZipEntry(source.name);
                zip.putNextEntry(entry);
                if (source.data != null) {
                    zip.write(source.data);
                } else if (source.file != null && source.file.isFile()) {
                    try (InputStream in = new BufferedInputStream(new FileInputStream(source.file))) {
                        int read;
                        while ((read = in.read(buffer)) != -1) {
                            zip.write(buffer, 0, read);
                        }
                    }
                }
                zip.closeEntry();
                done++;
                if (listener != null) {
                    listener.onProgress(source.name, total == 0 ? 100 : (int) (done * 100L / total));
                }
            }
            zip.finish();
            if (listener != null) {
                listener.onFinished(true, "Backup created");
            }
        } catch (Exception e) {
            if (listener != null) {
                listener.onFinished(false, "Backup failed: " + e.getMessage());
            }
        } finally {
            if (zip != null) {
                try {
                    zip.close();
                } catch (IOException ignored) {
                }
            }
            try {
                output.close();
            } catch (IOException ignored) {
            }
        }
    }

    public static File createBackup(Project project, File outputFile, boolean includeFiles,
                                    boolean includeLocalLibs, ProgressListener listener) {
        File parent = outputFile.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }
        try {
            createBackup(project, new FileOutputStream(outputFile), includeFiles, includeLocalLibs,
                    listener);
        } catch (Exception e) {
            if (listener != null) {
                listener.onFinished(false, "Backup failed: " + e.getMessage());
            }
        }
        return outputFile;
    }

    // ---------------------------------------------------------------------
    // Extract / inspect
    // ---------------------------------------------------------------------

    public static boolean extractTo(InputStream input, File destination, ProgressListener listener) {
        byte[] buffer = new byte[8192];
        boolean success = false;
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(input))) {
            ZipEntry entry;
            int count = 0;
            while ((entry = zip.getNextEntry()) != null) {
                File target = safeFile(destination, entry.getName());
                if (target == null) {
                    continue;
                }
                if (entry.isDirectory()) {
                    target.mkdirs();
                } else {
                    File parent = target.getParentFile();
                    if (parent != null && !parent.exists()) {
                        parent.mkdirs();
                    }
                    try (OutputStream out = new FileOutputStream(target)) {
                        int read;
                        while ((read = zip.read(buffer)) != -1) {
                            out.write(buffer, 0, read);
                        }
                    }
                }
                zip.closeEntry();
                count++;
                if (listener != null) {
                    listener.onProgress(entry.getName(), -1);
                }
            }
            success = true;
            if (listener != null) {
                listener.onFinished(true, "Extracted " + count + " entries");
            }
        } catch (Exception e) {
            if (listener != null) {
                listener.onFinished(false, "Extract failed: " + e.getMessage());
            }
        }
        return success;
    }

    /** Reads the {@code project} entry from an archive without extracting everything. */
    public static Project readProjectFromArchive(InputStream input) {
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(input))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if ("project".equals(entry.getName())) {
                    byte[] raw = readAll(zip);
                    String json = CryptoUtil.decryptToString(raw);
                    return Project.fromJson(json);
                }
                zip.closeEntry();
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /** Reads the {@code project} entry from an already extracted backup. */
    public static Project readProjectFromExtracted(File extractedDir) {
        Project project = Project.fromJson(FileUtil.readDecrypted(new File(extractedDir, "project")));
        if (project.scId == null) {
            project.scId = "";
        }
        return project;
    }

    // ---------------------------------------------------------------------
    // Restore
    // ---------------------------------------------------------------------

    /**
     * Copies an extracted backup back into {@code .sketchware}.
     *
     * @param replaceExisting when true the target project folders are wiped first
     */
    public static boolean restoreFromExtracted(File extractedDir, Project project, boolean replaceExisting,
                                               ProgressListener listener) {
        return restoreFromExtracted(extractedDir, project, project.scId, replaceExisting, listener);
    }

    /**
     * @param sourceScId the project id used inside the archive; only differs from
     *                   {@code project.scId} when the backup is imported as a new project
     */
    public static boolean restoreFromExtracted(File extractedDir, Project project, String sourceScId,
                                               boolean replaceExisting, ProgressListener listener) {
        String scId = project.scId;
        if (scId == null || scId.isEmpty()) {
            if (listener != null) {
                listener.onFinished(false, "Backup has no project id");
            }
            return false;
        }
        try {
            File dataTarget = SketchwareUtil.projectDataDir(scId);
            File extractedData = new File(extractedDir, "data");
            if (replaceExisting) {
                FileUtil.clearDirectory(dataTarget);
            }
            dataTarget.mkdirs();
            copyContents(extractedData, dataTarget);

            // resources
            for (String type : new String[]{"images", "fonts", "sounds"}) {
                File source = new File(extractedDir, "resources/" + type + "/" + sourceScId);
                if (source.exists()) {
                    File target = SketchwareUtil.projectResourceDir(scId, type);
                    if (replaceExisting) {
                        FileUtil.clearDirectory(target);
                    }
                    FileUtil.copyDirectory(source, target);
                }
            }

            // custom app icon is a single file: resources/icons/<sc_id>.png
            File icon = new File(extractedDir, "resources/icons/" + sourceScId + ".png");
            if (icon.exists()) {
                File iconTarget = new File(SketchwareUtil.resourcesDir(), "icons/" + scId + ".png");
                FileUtil.copyFile(icon, iconTarget);
            }

            // local libraries
            File localLibs = new File(extractedDir, "local_libs");
            if (localLibs.exists()) {
                copyContents(localLibs, SketchwareUtil.localLibsDir());
            }

            // metadata
            SketchwareUtil.writeProject(project);

            // generated Android project is rebuilt by Sketchware, drop stale cache
            File generated = new File(SketchwareUtil.sketchwareDir(), "mysc/" + scId);
            if (generated.exists()) {
                FileUtil.delete(generated);
            }

            if (listener != null) {
                listener.onProgress("", 100);
                listener.onFinished(true, "Restored " + project.displayName());
            }
            return true;
        } catch (Exception e) {
            if (listener != null) {
                listener.onFinished(false, "Restore failed: " + e.getMessage());
            }
            return false;
        }
    }

    /** Imports an extracted backup as a brand new project (new id, no clashes). */
    public static Project importAsNewProject(File extractedDir, ProgressListener listener) {
        Project project = readProjectFromExtracted(extractedDir);
        String sourceScId = project.scId;
        project.scId = SketchwareUtil.newProjectId();
        project.regDate = SketchwareUtil.timestamp();
        boolean ok = restoreFromExtracted(extractedDir, project, sourceScId, false, listener);
        return ok ? project : null;
    }

    private static void copyContents(File sourceDir, File targetDir) {
        if (sourceDir == null || !sourceDir.isDirectory()) {
            return;
        }
        File[] children = sourceDir.listFiles();
        if (children == null) {
            return;
        }
        if (!targetDir.exists()) {
            targetDir.mkdirs();
        }
        for (File child : children) {
            File target = new File(targetDir, child.getName());
            if (child.isDirectory()) {
                FileUtil.copyDirectory(child, target);
            } else {
                FileUtil.copyFile(child, target);
            }
        }
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private static byte[] readAll(InputStream input) throws IOException {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int read;
        while ((read = input.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
        return out.toByteArray();
    }

    private static File safeFile(File root, String entryName) {
        File file = new File(root, entryName);
        try {
            String rootPath = root.getCanonicalPath();
            String filePath = file.getCanonicalPath();
            if (!filePath.startsWith(rootPath)) {
                return null;
            }
        } catch (IOException e) {
            return null;
        }
        return file;
    }

    /** A single archive entry, either backed by a file or by an in memory blob. */
    public static class ZipEntrySource {
        public final String name;
        public final File file;
        public final byte[] data;

        public ZipEntrySource(String name, File file) {
            this.name = name;
            this.file = file;
            this.data = null;
        }

        public ZipEntrySource(String name, byte[] data) {
            this.name = name;
            this.file = null;
            this.data = data;
        }
    }
}
