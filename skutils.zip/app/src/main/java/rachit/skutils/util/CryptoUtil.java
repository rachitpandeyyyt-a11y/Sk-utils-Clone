package rachit.skutils.util;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Sketchware encrypts project data files with AES-128/CBC using the key and the
 * IV "sketchwaresecure". This class exposes decrypt/encrypt helpers plus the
 * small Base64 used in the old backup format.
 */
public final class CryptoUtil {

    /** Sketchware's hard coded AES key/IV. */
    private static final byte[] KEY = "sketchwaresecure".getBytes(StandardCharsets.UTF_8);
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    private static final String BASE64_TABLE =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    private CryptoUtil() {
    }

    public static byte[] decrypt(byte[] encrypted) {
        if (encrypted == null || encrypted.length == 0) {
            return new byte[0];
        }
        try {
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(KEY, "AES"), new IvParameterSpec(KEY));
            return cipher.doFinal(encrypted);
        } catch (Exception e) {
            return new byte[0];
        }
    }

    public static byte[] encrypt(byte[] plain) {
        if (plain == null) {
            plain = new byte[0];
        }
        try {
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(KEY, "AES"), new IvParameterSpec(KEY));
            return cipher.doFinal(plain);
        } catch (Exception e) {
            return new byte[0];
        }
    }

    public static String decryptToString(byte[] encrypted) {
        return new String(decrypt(encrypted), StandardCharsets.UTF_8);
    }

    public static byte[] encryptString(String plain) {
        return encrypt(plain.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * The legacy backup format used by older Sketchware builds is just Base64.
     * Decrypting tolerates both a raw Base64 payload and an AES encrypted blob.
     */
    public static String decodeLegacy(String data) {
        byte[] raw = base64Decode(data);
        if (raw.length == 0) {
            return data;
        }
        String decrypted = decryptToString(raw);
        return decrypted.isEmpty() ? data : decrypted;
    }

    public static String base64Decode(String str) {
        return new String(base64DecodeBytes(str), StandardCharsets.UTF_8);
    }

    public static byte[] base64DecodeBytes(String str) {
        if (str == null) {
            return new byte[0];
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int buffer = 0;
        int bits = 0;
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            int value = BASE64_TABLE.indexOf(c);
            if (value < 0) {
                continue;
            }
            buffer = (buffer << 6) | value;
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                out.write((buffer >> bits) & 0xFF);
            }
        }
        return out.toByteArray();
    }

    public static String base64Encode(byte[] data) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (; i + 2 < data.length; i += 3) {
            int triple = (data[i] & 0xFF) << 16 | (data[i + 1] & 0xFF) << 8 | (data[i + 2] & 0xFF);
            sb.append(BASE64_TABLE.charAt((triple >> 18) & 0x3F));
            sb.append(BASE64_TABLE.charAt((triple >> 12) & 0x3F));
            sb.append(BASE64_TABLE.charAt((triple >> 6) & 0x3F));
            sb.append(BASE64_TABLE.charAt(triple & 0x3F));
        }
        if (i < data.length) {
            int remaining = data.length - i;
            int triple = (data[i] & 0xFF) << 16;
            if (remaining == 2) {
                triple |= (data[i + 1] & 0xFF) << 8;
            }
            sb.append(BASE64_TABLE.charAt((triple >> 18) & 0x3F));
            sb.append(BASE64_TABLE.charAt((triple >> 12) & 0x3F));
            sb.append(remaining == 2 ? BASE64_TABLE.charAt((triple >> 6) & 0x3F) : '=');
            sb.append('=');
        }
        return sb.toString();
    }
}
